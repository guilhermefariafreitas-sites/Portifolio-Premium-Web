import express from 'express';
import { ZipArchive, type ArchiverError } from 'archiver';
import path from 'path';
import fs from 'fs';
import 'dotenv/config';

const PORT = Number(process.env.PORT) || 3000;
const ROOT_DIR = process.cwd();

async function startServer() {
  const app = express();

  app.get('/api/download-project', (_req, res) => {
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader(
      'Content-Disposition',
      'attachment; filename="premium-web-projeto.zip"'
    );

    const archive = new ZipArchive({
      zlib: { level: 9 },
    });

    archive.on('warning', (err: ArchiverError) => {
      if (err.code === 'ENOENT') {
        console.warn('Archive warning:', err.message);
      } else {
        console.error('Archive error:', err);
      }
    });

    archive.on('error', (err: ArchiverError) => {
      console.error('Failed to create project zip:', err);
      if (!res.headersSent) {
        res.status(500).json({ error: 'Falha ao gerar o arquivo ZIP do projeto.' });
      } else {
        res.end();
      }
    });

    archive.pipe(res);

    archive.glob('**/*', {
      cwd: ROOT_DIR,
      dot: true,
      ignore: [
        'node_modules/**',
        'dist/**',
        '.git/**',
        '.aistudio/**',
        '.env',
        '.env.local',
        '.env.*.local',
        '*.log',
        'server.js',
      ],
    });

    archive.finalize();
  });

  if (process.env.NODE_ENV === 'production') {
    const distDir = path.join(ROOT_DIR, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      const indexFile = path.join(distDir, 'index.html');
      if (fs.existsSync(indexFile)) {
        res.sendFile(indexFile);
      } else {
        res.status(404).send('Build output not found. Run npm run build first.');
      }
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Premium Web server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
