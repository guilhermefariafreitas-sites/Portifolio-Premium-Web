# Premium Web — Portfólio Institucional

Site oficial e portfólio de alta conversão da **Premium Web**, desenvolvido com React, TypeScript, Tailwind CSS e Framer Motion.

## Como executar localmente

```bash
npm install
npm run dev
```

O servidor será iniciado em `http://localhost:3000`.

## Build de produção

```bash
npm run build
npm start
```
