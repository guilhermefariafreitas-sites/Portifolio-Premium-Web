import { motion } from 'motion/react';
import { TESTIMONIALS } from '../data/agencyData';

export function TestimonialsSection() {
  return (
    <section
      id="depoimentos"
      className="border-b border-slate-300/12 bg-[#05070B] py-16 sm:py-20"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl">
          <p className="text-sm font-medium text-slate-400">Depoimentos de Clientes</p>
          <h2
            className="mt-2 font-display font-bold tracking-tight text-white text-balance"
            style={{ fontSize: 'clamp(1.75rem, 3vw, 2.45rem)', lineHeight: 1.15 }}
          >
            Empresários que tiraram o projeto do papel e aumentaram suas vendas.
          </h2>
        </div>

        <div className="mt-10 grid grid-cols-1 gap-6 md:grid-cols-3">
          {TESTIMONIALS.map((item, idx) => (
            <motion.blockquote
              key={item.id}
              initial={{ opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.4, delay: idx * 0.06, ease: [0.16, 1, 0.3, 1] }}
              className="flex flex-col justify-between rounded-2xl border border-slate-300/15 bg-[#091221] p-6"
            >
              <div>
                <p className="font-mono text-xs font-medium tabular-nums text-blue-300">
                  {item.outcome}
                </p>
                <p className="mt-4 text-sm leading-relaxed text-slate-200 sm:text-base">
                  “{item.quote}”
                </p>
              </div>

              <footer className="mt-6 border-t border-slate-300/10 pt-4">
                <p className="font-display text-sm font-semibold text-white">{item.name}</p>
                <p className="mt-0.5 text-xs text-slate-400">
                  {item.role} · {item.company} · {item.city}
                </p>
              </footer>
            </motion.blockquote>
          ))}
        </div>
      </div>
    </section>
  );
}
