import { useMemo, useState } from 'react';
import { Search, ArrowUpRight, MessageCircle } from 'lucide-react';
import {
  BUSINESS_SEGMENTS,
  SEGMENT_CATEGORIES,
  SegmentCategory,
  getWhatsAppUrl,
} from '../data/agencyData';

export function ServicesSection() {
  const [selectedCategory, setSelectedCategory] = useState<SegmentCategory>('Todos');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredSegments = useMemo(() => {
    const query = searchTerm.trim().toLowerCase();
    return BUSINESS_SEGMENTS.filter((item) => {
      const matchesCategory =
        selectedCategory === 'Todos' || item.category === selectedCategory;
      const matchesQuery =
        query === '' ||
        item.name.toLowerCase().includes(query) ||
        item.focus.toLowerCase().includes(query) ||
        item.category.toLowerCase().includes(query);
      return matchesCategory && matchesQuery;
    });
  }, [selectedCategory, searchTerm]);

  return (
    <section
      id="servicos"
      className="border-b border-slate-300/12 bg-[#05070B] py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-2xl">
            <p className="text-sm font-medium text-slate-400">
              Soluções Sob Medida por Segmento
            </p>
            <h2
              className="mt-2 font-display font-bold tracking-tight text-white text-balance"
              style={{ fontSize: 'clamp(1.75rem, 3.2vw, 2.65rem)', lineHeight: 1.15 }}
            >
              Criamos o site ideal para o seu ramo faturar mais todos os dias.
            </h2>
            <p className="mt-3 text-base leading-relaxed text-slate-300">
              Cada mercado tem um jeito próprio de convencer o cliente. Escolha o seu segmento
              abaixo para solicitar uma proposta personalizada direto no WhatsApp.
            </p>
          </div>

          <div className="shrink-0">
            <a
              href={getWhatsAppUrl(
                'Olá! Quero solicitar um orçamento no WhatsApp para o site da minha empresa.'
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex min-h-[44px] items-center gap-2 rounded-lg bg-[#1D4ED8] px-5 py-3 text-sm font-semibold text-white transition-colors duration-150 hover:bg-[#1E40AF] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-400"
            >
              <MessageCircle className="h-4 w-4" aria-hidden="true" />
              <span>Solicitar orçamento no WhatsApp</span>
            </a>
          </div>
        </div>

        {/* Filter Bar + Search Input */}
        <div className="mt-10 flex flex-col gap-4 border-y border-slate-300/12 py-5 lg:flex-row lg:items-center lg:justify-between">
          <div
            role="tablist"
            aria-label="Filtrar segmentos por categoria"
            className="flex flex-wrap items-center gap-2"
          >
            {SEGMENT_CATEGORIES.map((category) => {
              const isActive = selectedCategory === category;
              return (
                <button
                  key={category}
                  type="button"
                  role="tab"
                  aria-selected={isActive}
                  onClick={() => setSelectedCategory(category)}
                  className={`min-h-[40px] rounded-lg px-3.5 py-2 text-xs font-semibold transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-blue-400 ${
                    isActive
                      ? 'bg-[#1D4ED8] text-white'
                      : 'border border-slate-300/15 bg-[#0A1324] text-slate-300 hover:border-slate-300/30 hover:text-white'
                  }`}
                >
                  {category}
                </button>
              );
            })}
          </div>

          <div className="relative w-full lg:w-72">
            <Search
              className="pointer-events-none absolute top-1/2 left-3.5 h-4 w-4 -translate-y-1/2 text-slate-400"
              aria-hidden="true"
            />
            <input
              type="search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar segmento (ex: Pizzaria)..."
              aria-label="Buscar segmento de negócio"
              className="min-h-[42px] w-full rounded-lg border border-slate-300/15 bg-[#0A1324] pr-4 pl-10 text-sm text-white placeholder-slate-400 transition-colors focus:border-blue-500 focus:outline-none"
            />
          </div>
        </div>

        {/* Segments Grid */}
        {filteredSegments.length === 0 ? (
          <div className="mt-8 rounded-xl border border-slate-300/15 bg-[#091221] p-8 text-center">
            <p className="font-display text-lg font-semibold text-white">
              Não encontrou o seu segmento listado?
            </p>
            <p className="mt-2 text-sm text-slate-300">
              Criamos sites para qualquer tipo de empresa no Brasil. Fale com a nossa equipe e
              receba uma proposta sob medida hoje mesmo.
            </p>
            <a
              href={getWhatsAppUrl(
                `Olá! Procuro um site para o segmento "${searchTerm || 'personalizado'}" e gostaria de solicitar um orçamento.`
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-5 inline-flex min-h-[44px] items-center gap-2 rounded-lg bg-[#1D4ED8] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#1E40AF]"
            >
              <span>Consultar meu segmento no WhatsApp</span>
              <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
            </a>
          </div>
        ) : (
          <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {filteredSegments.map((segment) => (
              <a
                key={segment.id}
                href={getWhatsAppUrl(
                  `Olá! Tenho interesse em criar um site para ${segment.name}. Gostaria de solicitar um orçamento.`
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex flex-col justify-between rounded-xl border border-slate-300/12 bg-[#091221]/85 p-5 transition-all duration-150 hover:border-slate-200/35 hover:bg-[#0D1A30] focus-visible:outline-2 focus-visible:outline-blue-400"
              >
                <div>
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-xs font-medium text-slate-400">
                      {segment.category}
                    </span>
                    <ArrowUpRight
                      className="h-4 w-4 text-slate-400 transition-transform duration-150 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-white"
                      aria-hidden="true"
                    />
                  </div>
                  <h3 className="mt-2 font-display text-lg font-semibold text-white">
                    {segment.name}
                  </h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-slate-300">
                    {segment.focus}
                  </p>
                </div>

                <div className="mt-4 border-t border-slate-300/10 pt-3 text-xs font-semibold text-slate-200 transition-colors group-hover:text-white">
                  Solicitar orçamento para {segment.name}
                </div>
              </a>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
