import { motion } from 'motion/react';
import { MessageCircle, ArrowRight } from 'lucide-react';
import { ABOUT_STORY, CONTACT_INFO, getWhatsAppUrl } from '../data/agencyData';
import { SafeImage } from './SafeImage';

export function HeroSection() {
  return (
    <section
      id="inicio"
      className="relative overflow-hidden border-b border-slate-300/12 bg-[#05070B]"
    >
      {/* Subtle navy architectural radial ambient */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 h-[520px] bg-[radial-gradient(ellipse_75%_60%_at_70%_10%,rgba(22,48,96,0.34),transparent_70%)]"
      />

      <div className="relative mx-auto max-w-6xl px-4 pt-12 pb-12 sm:px-6 lg:px-8 lg:pt-20 lg:pb-16">
        {/* 2-Column Hero Split with matched stretch height */}
        <div className="grid grid-cols-1 items-stretch gap-10 lg:grid-cols-12 lg:gap-12">
          {/* Left Column: Proposition & Primary Action */}
          <div className="flex flex-col justify-between lg:col-span-6">
            <div>
              <p className="text-sm font-medium tracking-wide text-slate-300">
                Criação de Sites Profissionais · Atendimento em todo o Brasil
              </p>

              <h1
                className="mt-4 font-display font-bold tracking-tight text-white text-balance"
                style={{ fontSize: 'clamp(2.25rem, 4.1vw, 3.65rem)', lineHeight: 1.08 }}
              >
                Sua empresa merece ser vista.{' '}
                <span className="metallic-text">Nós fazemos isso acontecer!</span>
              </h1>

              <p className="mt-6 max-w-xl text-base leading-relaxed text-slate-300 sm:text-lg">
                Transformamos a presença digital de negócios que querem aumentar seu faturamento.
                Sites rápidos, pensados para converter visitantes do celular em clientes reais
                diretamente no seu WhatsApp.
              </p>
            </div>

            <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center sm:gap-4">
              <a
                href={getWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-[48px] items-center justify-center gap-2.5 rounded-lg bg-[#1D4ED8] px-6 py-3.5 text-sm font-semibold text-white shadow-[0_0_24px_rgba(29,78,216,0.32)] transition-all duration-150 hover:bg-[#1E40AF] active:scale-[0.99] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-400"
              >
                <MessageCircle className="h-4 w-4" aria-hidden="true" />
                <span>Solicitar orçamento no WhatsApp</span>
              </a>

              <a
                href="#portfolio"
                className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-lg border border-slate-300/20 bg-[#0B162C]/70 px-5 py-3.5 text-sm font-semibold text-slate-100 transition-colors duration-150 hover:border-slate-300/40 hover:bg-[#102040] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-300"
              >
                <span>Conhecer projetos</span>
                <ArrowRight className="h-4 w-4 text-slate-300" aria-hidden="true" />
              </a>
            </div>
          </div>

          {/* Right Column: Dominant Visual Carrier */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6"
          >
            <div className="relative h-full min-h-[280px] overflow-hidden rounded-2xl border border-slate-300/18 bg-[#0A1324] lg:min-h-[420px]">
              <SafeImage
                src="/src/assets/images/hero_premium_studio_1794594313004.jpg"
                alt="Estúdio Premium Web com monitor exibindo interface moderna em tema escuro e metálico"
                title={CONTACT_INFO.brandName}
                loading="eager"
                className="h-full w-full object-cover lg:h-full"
              />
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#05070B]/85 via-[#05070B]/20 to-transparent"
              />
              <div className="absolute inset-x-0 bottom-0 p-5 sm:p-6">
                <p className="text-xs font-medium tracking-wide text-slate-300">
                  Alto Contraste · Performance Mobile · Conversão Direta
                </p>
                <p className="mt-1 font-display text-base font-semibold text-white sm:text-lg">
                  Projetos desenvolvidos com foco em credibilidade e faturamento.
                </p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Full-Width 3-Column Differential Strip Below Split */}
        <div className="mt-12 border-t border-slate-300/12 pt-10">
          <div className="grid grid-cols-1 gap-6 md:grid-cols-3 md:gap-8">
            {ABOUT_STORY.pillars.map((pillar) => (
              <div
                key={pillar.index}
                className="rounded-xl border border-slate-300/12 bg-[#091221]/80 p-6 transition-colors duration-150 hover:border-slate-300/25"
              >
                <div className="flex items-baseline gap-2.5">
                  <span className="font-mono text-xs font-medium tabular-nums text-slate-400">
                    {pillar.index}.
                  </span>
                  <h2 className="font-display text-lg font-semibold text-white">
                    {pillar.title}
                  </h2>
                </div>
                <p className="mt-2.5 text-sm leading-relaxed text-slate-300">
                  {pillar.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
