import { Instagram, MessageCircle } from 'lucide-react';
import { CONTACT_INFO, getWhatsAppUrl } from '../data/agencyData';

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="border-t border-slate-300/12 bg-[#04060A] py-12">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-8 md:flex-row md:items-start md:justify-between">
          <div className="max-w-sm">
            <a href="#inicio" className="font-display text-xl font-bold tracking-tight text-white">
              {CONTACT_INFO.brandName}
            </a>
            <p className="mt-2 text-sm leading-relaxed text-slate-400">
              {CONTACT_INFO.tagline}
            </p>
            <p className="mt-3 text-xs text-slate-500">{CONTACT_INFO.location}</p>
          </div>

          <div className="flex flex-wrap gap-10 text-sm">
            <div>
              <p className="font-display text-xs font-semibold tracking-wide text-slate-300">
                Navegação
              </p>
              <ul className="mt-3 space-y-2 text-slate-400">
                <li>
                  <a href="#sobre" className="transition-colors hover:text-white">
                    Sobre
                  </a>
                </li>
                <li>
                  <a href="#servicos" className="transition-colors hover:text-white">
                    Serviços
                  </a>
                </li>
                <li>
                  <a href="#portfolio" className="transition-colors hover:text-white">
                    Portfólio
                  </a>
                </li>
                <li>
                  <a href="#planos" className="transition-colors hover:text-white">
                    Planos
                  </a>
                </li>
                <li>
                  <a href="#contato" className="transition-colors hover:text-white">
                    Contato
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <p className="font-display text-xs font-semibold tracking-wide text-slate-300">
                Atendimento Direto
              </p>
              <ul className="mt-3 space-y-2.5 text-slate-400">
                <li>
                  <a
                    href={getWhatsAppUrl()}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 transition-colors hover:text-white"
                  >
                    <MessageCircle className="h-4 w-4 text-blue-400" aria-hidden="true" />
                    <span className="font-mono tabular-nums">{CONTACT_INFO.whatsappDisplay}</span>
                  </a>
                </li>
                <li>
                  <a
                    href={CONTACT_INFO.instagramUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 transition-colors hover:text-white"
                  >
                    <Instagram className="h-4 w-4 text-slate-300" aria-hidden="true" />
                    <span>@{CONTACT_INFO.instagramHandle}</span>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="mt-10 flex flex-col gap-2 border-t border-slate-300/10 pt-6 text-xs text-slate-500 sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {currentYear} {CONTACT_INFO.brandName}. Todos os direitos reservados.
          </p>
          <p>Atendimento humanizado · Design responsivo · Entrega no mesmo dia</p>
        </div>
      </div>
    </footer>
  );
}
