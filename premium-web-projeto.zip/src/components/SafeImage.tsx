import { useState } from 'react';
import { Monitor } from 'lucide-react';

interface SafeImageProps {
  src: string;
  alt: string;
  title?: string;
  className?: string;
  loading?: 'eager' | 'lazy';
}

export function SafeImage({
  src,
  alt,
  title,
  className = '',
  loading = 'lazy',
}: SafeImageProps) {
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    return (
      <div
        className={`flex flex-col items-center justify-center gap-3 bg-gradient-to-br from-[#0B162C] via-[#070D19] to-[#05070B] border border-slate-300/15 p-6 text-center ${className}`}
        role="img"
        aria-label={alt}
      >
        <Monitor className="h-8 w-8 text-slate-400" strokeWidth={1.5} />
        {title && (
          <span className="font-display text-sm font-medium tracking-tight text-slate-200">
            {title}
          </span>
        )}
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      loading={loading}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={className}
    />
  );
}
