import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowUpRight, Maximize2, MessageCircle, X } from 'lucide-react';
import { PORTFOLIO_PROJECTS, PortfolioProject, getWhatsAppUrl } from '../data/agencyData';
import { SafeImage } from './SafeImage';

export function PortfolioSection() {
  const [activeProject, setActiveProject] = useState<PortfolioProject | null>(null);

  useEffect(() => {
    if (!activeProject) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setActiveProject(null);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [activeProject]);

  return (
    <section
      id="portfolio"
      className="border-b border-slate-300/12 bg-[#070D19] py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-2xl">
            <p className="text-sm font-medium text-slate-400">Portfólio & Resultados</p>
            <h2
              className="mt-2 font-display font-bold tracking-tight text-white text-balance"
              style={{ fontSize: 'clamp(1.75rem, 3.2vw, 2.65rem)', lineHeight: 1.15 }}
            >
              Projetos criados para gerar autoridade e pedidos todos os dias.
            </h2>
          </div>

          <a
            href={getWhatsAppUrl(
              'Olá! Vi o portfólio da Premium Web e quero um site profissional nesse padrão para minha empresa.'
            )}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex min-h-[44px] items-center gap-2 rounded-lg bg-[#1D4ED8] px-5 py-3 text-sm font-semibold text-white transition-colors duration-150 hover:bg-[#1E40AF] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-400"
          >
            <MessageCircle className="h-4 w-4" aria-hidden="true" />
            <span>Solicitar orçamento no WhatsApp</span>
          </a>
        </div>

        {/* Dynamic Bento Showcase Grid */}
        <div className="mt-10 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-12">
          {PORTFOLIO_PROJECTS.map((project, index) => {
            const isLarge = index === 0 || index === 3;
            const colSpan = isLarge ? 'lg:col-span-7' : 'lg:col-span-5';

            return (
              <motion.article
                key={project.id}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-60px' }}
                transition={{ duration: 0.4, delay: index * 0.05, ease: [0.16, 1, 0.3, 1] }}
                className={`group flex flex-col overflow-hidden rounded-2xl border border-slate-300/15 bg-[#091221] transition-colors duration-150 hover:border-slate-200/35 ${colSpan}`}
              >
                <button
                  type="button"
                  onClick={() => setActiveProject(project)}
                  aria-label={`Ver detalhes do projeto ${project.client}`}
                  className="relative aspect-[16/10] w-full overflow-hidden bg-[#05070B] text-left focus-visible:outline-2 focus-visible:outline-blue-400"
                >
                  <SafeImage
                    src={project.image}
                    alt={project.imageAlt}
                    title={project.client}
                    className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                  />
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#05070B]/80 via-transparent to-transparent"
                  />
                  <span className="absolute right-4 bottom-4 inline-flex items-center gap-1.5 rounded-lg border border-slate-300/25 bg-[#05070B]/85 px-3 py-1.5 text-xs font-semibold text-white backdrop-blur-sm">
                    <Maximize2 className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Inspecionar projeto</span>
                  </span>
                </button>

                <div className="flex flex-1 flex-col justify-between p-6">
                  <div>
                    {/* Clean unboxed metadata with typographic separators */}
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
                      <span className="font-medium text-slate-300">{project.segment}</span>
                      <span aria-hidden="true">·</span>
                      <span>{project.location}</span>
                    </div>

                    <h3 className="mt-2 font-display text-xl font-semibold text-white">
                      {project.client} — {project.title}
                    </h3>

                    <p className="mt-2.5 text-sm leading-relaxed text-slate-300">
                      {project.summary}
                    </p>
                  </div>

                  <div className="mt-5 border-t border-slate-300/10 pt-4">
                    <p className="font-mono text-xs font-medium tabular-nums text-slate-200">
                      {project.resultMetric}
                    </p>

                    <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
                      <button
                        type="button"
                        onClick={() => setActiveProject(project)}
                        className="inline-flex min-h-[40px] items-center gap-1.5 text-xs font-semibold text-slate-200 underline-offset-4 hover:text-white hover:underline focus-visible:outline-2 focus-visible:outline-blue-400"
                      >
                        <span>Ver estudo completo</span>
                      </button>

                      <a
                        href={getWhatsAppUrl(
                          `Olá! Gostei muito do projeto "${project.client}" (${project.segment}) e quero um orçamento para minha empresa.`
                        )}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex min-h-[40px] items-center gap-1.5 text-xs font-semibold text-blue-300 transition-colors hover:text-white focus-visible:outline-2 focus-visible:outline-blue-400"
                      >
                        <span>Quero um site assim</span>
                        <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
                      </a>
                    </div>
                  </div>
                </div>
              </motion.article>
            );
          })}
        </div>
      </div>

      {/* Lightbox / Project Detail Modal */}
      <AnimatePresence>
        {activeProject && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-sm"
            role="dialog"
            aria-modal="true"
            aria-labelledby="modal-project-title"
            onClick={() => setActiveProject(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.97, y: 12 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.97, y: 12 }}
              transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
              onClick={(e) => e.stopPropagation()}
              className="relative max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-2xl border border-slate-300/20 bg-[#091221] shadow-2xl"
            >
              <button
                type="button"
                onClick={() => setActiveProject(null)}
                aria-label="Fechar visualização do projeto"
                className="absolute top-4 right-4 z-10 inline-flex h-10 w-10 items-center justify-center rounded-lg border border-slate-300/25 bg-[#05070B]/90 text-white transition-colors hover:bg-[#11254A] focus-visible:outline-2 focus-visible:outline-blue-400"
              >
                <X className="h-5 w-5" />
              </button>

              <div className="aspect-[16/9] w-full overflow-hidden bg-[#05070B]">
                <SafeImage
                  src={activeProject.image}
                  alt={activeProject.imageAlt}
                  title={activeProject.client}
                  className="h-full w-full object-cover"
                />
              </div>

              <div className="p-6 sm:p-8">
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
                  <span className="font-medium text-slate-200">{activeProject.segment}</span>
                  <span aria-hidden="true">·</span>
                  <span>{activeProject.location}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums text-blue-300">
                    {activeProject.resultMetric}
                  </span>
                </div>

                <h3
                  id="modal-project-title"
                  className="mt-2 font-display text-2xl font-bold text-white"
                >
                  {activeProject.client} — {activeProject.title}
                </h3>

                <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2">
                  <div>
                    <h4 className="text-xs font-semibold tracking-wide text-slate-400">
                      Desafio da Empresa
                    </h4>
                    <p className="mt-2 text-sm leading-relaxed text-slate-200">
                      {activeProject.challenge}
                    </p>
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold tracking-wide text-slate-400">
                      Solução Premium Web
                    </h4>
                    <p className="mt-2 text-sm leading-relaxed text-slate-200">
                      {activeProject.solution}
                    </p>
                  </div>
                </div>

                <div className="mt-6 border-t border-slate-300/12 pt-5">
                  <p className="text-xs font-semibold text-slate-400">Entregas Realizadas</p>
                  <p className="mt-2 text-sm text-slate-200">
                    {activeProject.deliverables.join(' · ')}
                  </p>
                </div>

                <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <a
                    href={getWhatsAppUrl(
                      `Olá! Quero solicitar um orçamento para um site inspirado no projeto ${activeProject.client}.`
                    )}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-lg bg-[#1D4ED8] px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-[#1E40AF]"
                  >
                    <MessageCircle className="h-4 w-4" aria-hidden="true" />
                    <span>Solicitar orçamento no WhatsApp</span>
                  </a>
                  <button
                    type="button"
                    onClick={() => setActiveProject(null)}
                    className="inline-flex min-h-[44px] items-center justify-center rounded-lg border border-slate-300/20 px-5 py-2.5 text-sm font-medium text-slate-200 hover:bg-[#0F1E3A]"
                  >
                    Fechar (ESC)
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
