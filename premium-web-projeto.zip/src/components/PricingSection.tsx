import { useEffect, useState } from 'react';
import { Check, Maximize2, MessageCircle, X } from 'lucide-react';
import { PRICING_PLANS, PricingPlan, getWhatsAppUrl } from '../data/agencyData';
import { SafeImage } from './SafeImage';

export function PricingSection() {
  const [zoomedPlan, setZoomedPlan] = useState<PricingPlan | null>(null);

  useEffect(() => {
    if (!zoomedPlan) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setZoomedPlan(null);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [zoomedPlan]);

  return (
    <section
      id="planos"
      className="border-b border-slate-300/12 bg-[#070D19] py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl">
          <p className="text-sm font-medium text-slate-400">Investimento Transparente</p>
          <h2
            className="mt-2 font-display font-bold tracking-tight text-white text-balance"
            style={{ fontSize: 'clamp(1.75rem, 3.2vw, 2.65rem)', lineHeight: 1.15 }}
          >
            Escolha o plano ideal para o seu negócio!
          </h2>
          <p className="mt-3 text-base leading-relaxed text-slate-300">
            Transforme sua presença online e conquiste mais clientes com sites rápidos,
            design responsivo e suporte especializado.
          </p>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-6 lg:grid-cols-3">
          {PRICING_PLANS.map((plan) => {
            const isRecommended = Boolean(plan.recommended);

            return (
              <article
                key={plan.id}
                className={`flex flex-col justify-between overflow-hidden rounded-2xl ${
                  isRecommended
                    ? 'border border-slate-200/35 bg-gradient-to-b from-[#102242] to-[#08101F]'
                    : 'border border-slate-300/14 bg-[#091221]'
                }`}
              >
                <div>
                  {/* Uploaded Plan Graphic */}
                  <button
                    type="button"
                    onClick={() => setZoomedPlan(plan)}
                    aria-label={`Ampliar arte do plano ${plan.name}`}
                    className="group relative block w-full overflow-hidden border-b border-slate-300/12 bg-[#05070B] focus-visible:outline-2 focus-visible:outline-blue-400"
                  >
                    <SafeImage
                      src={plan.image}
                      alt={plan.imageAlt}
                      title={plan.name}
                      className="aspect-[4/5] w-full object-contain bg-[#05070B] transition-transform duration-300 group-hover:scale-[1.02]"
                    />
                    <span className="absolute right-3 bottom-3 inline-flex items-center gap-1.5 rounded-lg border border-slate-300/25 bg-[#05070B]/85 px-2.5 py-1 text-xs font-medium text-white backdrop-blur-sm">
                      <Maximize2 className="h-3.5 w-3.5" aria-hidden="true" />
                      <span>Ampliar</span>
                    </span>
                  </button>

                  <div className="p-6 sm:p-7">
                    <div className="flex items-center justify-between gap-2">
                      <h3 className="font-display text-xl font-bold text-white">{plan.name}</h3>
                      {isRecommended && (
                        <span className="text-xs font-semibold text-blue-300">
                          Mais escolhido
                        </span>
                      )}
                    </div>

                    <p className="mt-2 text-sm leading-relaxed text-slate-300">{plan.subtitle}</p>

                    <div className="mt-5 border-y border-slate-300/12 py-4">
                      <div className="flex items-baseline gap-2">
                        <span className="font-mono text-3xl font-bold tabular-nums text-white sm:text-4xl">
                          {plan.price}
                        </span>
                        <span className="text-xs text-slate-400">{plan.billingNote}</span>
                      </div>
                      <p className="mt-1 text-xs font-medium text-slate-300">{plan.delivery}</p>
                    </div>

                    <ul className="mt-5 space-y-3">
                      {plan.features.map((feat) => (
                        <li key={feat} className="flex items-start gap-2.5 text-sm text-slate-200">
                          <Check
                            className="mt-0.5 h-4 w-4 shrink-0 text-blue-400"
                            aria-hidden="true"
                          />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="px-6 pb-6 sm:px-7 sm:pb-7">
                  <a
                    href={getWhatsAppUrl(
                      `Olá! Tenho interesse no plano "${plan.name}" (${plan.price}) da Premium Web. Gostaria de solicitar agora pelo WhatsApp.`
                    )}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`inline-flex min-h-[46px] w-full items-center justify-center gap-2 rounded-lg px-5 py-3 text-sm font-semibold transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-400 ${
                      isRecommended
                        ? 'bg-[#1D4ED8] text-white hover:bg-[#1E40AF]'
                        : 'border border-slate-300/25 bg-[#0D1A30] text-white hover:border-slate-200/45 hover:bg-[#132645]'
                    }`}
                  >
                    <MessageCircle className="h-4 w-4" aria-hidden="true" />
                    <span>{plan.ctaLabel}</span>
                  </a>
                </div>
              </article>
            );
          })}
        </div>
      </div>

      {/* Plan Image Lightbox Modal */}
      {zoomedPlan && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-label={`Visualização ampliada do plano ${zoomedPlan.name}`}
          onClick={() => setZoomedPlan(null)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative max-h-[92vh] w-full max-w-lg overflow-hidden rounded-2xl border border-slate-300/25 bg-[#091221] shadow-2xl"
          >
            <button
              type="button"
              onClick={() => setZoomedPlan(null)}
              aria-label="Fechar imagem ampliada"
              className="absolute top-3 right-3 z-10 inline-flex h-10 w-10 items-center justify-center rounded-lg border border-slate-300/25 bg-[#05070B]/90 text-white transition-colors hover:bg-[#11254A]"
            >
              <X className="h-5 w-5" />
            </button>
            <SafeImage
              src={zoomedPlan.image}
              alt={zoomedPlan.imageAlt}
              title={zoomedPlan.name}
              className="max-h-[78vh] w-full object-contain bg-[#05070B]"
            />
            <div className="flex items-center justify-between gap-4 border-t border-slate-300/15 p-4">
              <div>
                <p className="font-display text-base font-bold text-white">{zoomedPlan.name}</p>
                <p className="font-mono text-sm font-semibold tabular-nums text-blue-300">
                  {zoomedPlan.price}
                </p>
              </div>
              <a
                href={getWhatsAppUrl(
                  `Olá! Tenho interesse no plano "${zoomedPlan.name}" (${zoomedPlan.price}) da Premium Web.`
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-[42px] items-center gap-2 rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-semibold text-white hover:bg-[#1E40AF]"
              >
                <MessageCircle className="h-4 w-4" aria-hidden="true" />
                <span>Solicitar no WhatsApp</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
