import { motion } from 'motion/react';
import { MessageCircle } from 'lucide-react';
import { ABOUT_STORY, getWhatsAppUrl } from '../data/agencyData';
import { SafeImage } from './SafeImage';

export function AboutSection() {
  return (
    <section
      id="sobre"
      className="border-b border-slate-300/12 bg-[#070D19] py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 items-stretch gap-10 lg:grid-cols-12 lg:gap-14">
          {/* Left Visual Column */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5"
          >
            <div className="relative h-full min-h-[360px] overflow-hidden rounded-2xl border border-slate-300/15 bg-[#0A1324]">
              <SafeImage
                src="/src/assets/images/about_studio_craft_1794598323933.jpg"
                alt="Mesa de estúdio da Premium Web com notebook e monitor exibindo interfaces e código"
                title="Premium Web"
                className="aspect-[3/4] w-full object-cover lg:aspect-auto lg:h-full"
              />
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#05070B]/85 via-[#05070B]/25 to-transparent"
              />
              <div className="absolute inset-x-0 bottom-0 p-5">
                <p className="text-xs font-medium text-slate-300">
                  Propósito · Dedicação · Compromisso
                </p>
                <p className="mt-1 font-display text-sm font-semibold text-white">
                  Da paixão por tecnologia ao crescimento do seu negócio.
                </p>
              </div>
            </div>
          </motion.div>

          {/* Right Editorial Story Column */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.45, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-center lg:col-span-7"
          >
            <p className="text-sm font-medium text-slate-400">Sobre a Premium Web</p>

            <h2
              className="mt-3 font-display font-bold tracking-tight text-white text-balance"
              style={{ fontSize: 'clamp(1.75rem, 3vw, 2.5rem)', lineHeight: 1.15 }}
            >
              {ABOUT_STORY.heading}
            </h2>

            <div className="metallic-hairline my-6 h-px w-full" />

            <p className="text-base leading-relaxed text-slate-200 sm:text-lg sm:leading-relaxed">
              {ABOUT_STORY.paragraph}
            </p>

            <div className="mt-8 grid grid-cols-1 gap-6 border-t border-slate-300/12 pt-8 sm:grid-cols-3">
              <div>
                <p className="font-mono text-2xl font-semibold tabular-nums text-white">
                  31+
                </p>
                <p className="mt-1 text-sm text-slate-400">
                  Segmentos atendidos em todo o Brasil
                </p>
              </div>
              <div>
                <p className="font-mono text-2xl font-semibold tabular-nums text-white">
                  Mesmo dia
                </p>
                <p className="mt-1 text-sm text-slate-400">
                  Prazo ágil de entrega para projetos expressos
                </p>
              </div>
              <div>
                <p className="font-mono text-2xl font-semibold tabular-nums text-white">
                  100%
                </p>
                <p className="mt-1 text-sm text-slate-400">
                  Atendimento direto e humanizado no WhatsApp
                </p>
              </div>
            </div>

            <div className="mt-8">
              <a
                href={getWhatsAppUrl(
                  'Olá! Li a história da Premium Web e quero conversar sobre o site da minha empresa.'
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-[44px] items-center gap-2.5 rounded-lg bg-[#1D4ED8] px-6 py-3 text-sm font-semibold text-white transition-colors duration-150 hover:bg-[#1E40AF] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-400"
              >
                <MessageCircle className="h-4 w-4" aria-hidden="true" />
                <span>Solicitar orçamento no WhatsApp</span>
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
