import { useState } from 'react';
import { Menu, X, ArrowUpRight, Download, Loader2 } from 'lucide-react';
import { CONTACT_INFO, getWhatsAppUrl } from '../data/agencyData';

const NAV_LINKS = [
  { label: 'Sobre', href: '#sobre' },
  { label: 'Serviços', href: '#servicos' },
  { label: 'Portfólio', href: '#portfolio' },
  { label: 'Planos', href: '#planos' },
  { label: 'Contato', href: '#contato' },
];

export function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const handleDownloadZip = async () => {
    if (downloading) return;
    setDownloading(true);
    try {
      const response = await fetch('/api/download-project');
      if (!response.ok) {
        throw new Error('Falha ao gerar arquivo ZIP');
      }
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'premium-web-projeto.zip';
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Erro ao baixar ZIP do projeto:', error);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <header className="sticky top-0 z-40 border-b border-slate-300/12 bg-[#05070B]/88 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-8 px-4 sm:px-6 lg:px-8">
        {/* Zone 1: Brand Wordmark + Project ZIP Download Icon */}
        <div className="flex items-center gap-2.5 shrink-0">
          <a
            href="#inicio"
            className="font-display text-xl font-bold tracking-tight text-white whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-blue-500"
          >
            {CONTACT_INFO.brandName}
          </a>
          <button
            type="button"
            onClick={handleDownloadZip}
            disabled={downloading}
            title="Baixar arquivo ZIP do projeto para GitHub"
            aria-label="Baixar arquivo ZIP do projeto para GitHub"
            className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-slate-300/20 bg-[#0B162C] text-slate-200 transition-colors duration-150 hover:border-slate-200/45 hover:bg-[#132645] hover:text-white disabled:opacity-60 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-400"
          >
            {downloading ? (
              <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
            ) : (
              <Download className="h-4 w-4" aria-hidden="true" />
            )}
          </button>
        </div>

        {/* Zone 2: 5 concise single-line text nav links */}
        <nav
          aria-label="Navegação principal"
          className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-300"
        >
          {NAV_LINKS.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="relative py-1 text-slate-300 transition-colors duration-150 hover:text-white whitespace-nowrap shrink-0 after:absolute after:bottom-0 after:left-0 after:h-px after:w-0 after:bg-slate-200 after:transition-all after:duration-200 hover:after:w-full focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-blue-500"
            >
              {item.label}
            </a>
          ))}
        </nav>

        {/* Zone 3: Single primary action (desktop) + Mobile menu toggle */}
        <div className="flex items-center gap-3 shrink-0">
          <a
            href={getWhatsAppUrl()}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:inline-flex items-center gap-2 rounded-lg border border-slate-300/25 bg-[#11254A] px-4 py-2 text-sm font-semibold text-white transition-colors duration-150 hover:bg-[#19356B] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-400"
          >
            <span>Solicitar orçamento</span>
            <ArrowUpRight className="h-4 w-4 text-slate-200" aria-hidden="true" />
          </a>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-expanded={mobileOpen}
            aria-label={mobileOpen ? 'Fechar menu' : 'Abrir menu'}
            className="inline-flex h-11 w-11 items-center justify-center rounded-lg border border-slate-300/15 bg-[#0B162C] text-slate-100 transition-colors hover:bg-[#122244] md:hidden focus-visible:outline-2 focus-visible:outline-blue-400"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileOpen && (
        <div className="border-t border-slate-300/12 bg-[#070D19] px-4 py-5 md:hidden">
          <nav className="flex flex-col gap-1" aria-label="Navegação mobile">
            {NAV_LINKS.map((item) => (
              <a
                key={item.href}
                href={item.href}
                onClick={() => setMobileOpen(false)}
                className="flex min-h-[44px] items-center rounded-lg px-3 text-base font-medium text-slate-200 transition-colors hover:bg-[#0F1E3A] hover:text-white"
              >
                {item.label}
              </a>
            ))}
            <a
              href={getWhatsAppUrl()}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setMobileOpen(false)}
              className="mt-3 inline-flex min-h-[44px] items-center justify-center gap-2 rounded-lg bg-[#1D4ED8] px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-[#1E40AF]"
            >
              <span>Solicitar orçamento no WhatsApp</span>
              <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}
