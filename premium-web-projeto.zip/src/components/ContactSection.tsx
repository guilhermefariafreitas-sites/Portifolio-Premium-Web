import { FormEvent, useState } from 'react';
import { CheckCircle2, Instagram, MessageCircle, Phone } from 'lucide-react';
import {
  BUSINESS_SEGMENTS,
  CONTACT_INFO,
  PRICING_PLANS,
  getWhatsAppUrl,
} from '../data/agencyData';

interface FormErrors {
  name?: string;
  phone?: string;
  segment?: string;
}

export function ContactSection() {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [segment, setSegment] = useState('');
  const [plan, setPlan] = useState(PRICING_PLANS[1].name);
  const [message, setMessage] = useState('');
  const [errors, setErrors] = useState<FormErrors>({});
  const [submittedUrl, setSubmittedUrl] = useState<string | null>(null);

  const validate = (): FormErrors => {
    const nextErrors: FormErrors = {};
    if (name.trim().length < 2) {
      nextErrors.name = 'Informe seu nome para personalizar o atendimento.';
    }
    const digits = phone.replace(/\D/g, '');
    if (digits.length < 10) {
      nextErrors.phone = 'Informe um número de WhatsApp válido com DDD.';
    }
    if (!segment.trim()) {
      nextErrors.segment = 'Informe o segmento ou nome da sua empresa.';
    }
    return nextErrors;
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      setSubmittedUrl(null);
      return;
    }

    setErrors({});
    const formatted = [
      `Olá, Premium Web! Meu nome é ${name.trim()}.`,
      `WhatsApp para contato: ${phone.trim()}`,
      `Empresa / Segmento: ${segment.trim()}`,
      `Plano de interesse: ${plan}`,
      message.trim() ? `Detalhes do projeto: ${message.trim()}` : '',
    ]
      .filter(Boolean)
      .join('\n');

    setSubmittedUrl(getWhatsAppUrl(formatted));
  };

  return (
    <section id="contato" className="bg-[#05070B] py-16 sm:py-20 lg:py-24">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:gap-14">
          {/* Left Info Column */}
          <div className="lg:col-span-5">
            <p className="text-sm font-medium text-slate-400">Fale com a Premium Web</p>
            <h2
              className="mt-2 font-display font-bold tracking-tight text-white text-balance"
              style={{ fontSize: 'clamp(1.75rem, 3.2vw, 2.55rem)', lineHeight: 1.15 }}
            >
              Pronto para ver a sua empresa se destacando na internet?
            </h2>
            <p className="mt-4 text-base leading-relaxed text-slate-300">
              Preencha seus dados ao lado para montar seu briefing ou chame agora mesmo no
              WhatsApp. Nosso atendimento é humano, rápido e focado no que faz sua empresa
              vender mais.
            </p>

            <div className="mt-8 space-y-4 border-t border-slate-300/12 pt-8">
              <a
                href={getWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between rounded-xl border border-slate-300/15 bg-[#091221] p-4 transition-colors hover:border-slate-200/35 hover:bg-[#0E1B33] focus-visible:outline-2 focus-visible:outline-blue-400"
              >
                <div className="flex items-center gap-3.5">
                  <Phone className="h-5 w-5 text-blue-400" aria-hidden="true" />
                  <div>
                    <p className="text-xs font-medium text-slate-400">WhatsApp Comercial</p>
                    <p className="font-mono text-sm font-semibold tabular-nums text-white">
                      {CONTACT_INFO.whatsappDisplay}
                    </p>
                  </div>
                </div>
                <span className="text-xs font-semibold text-blue-300">Abrir conversa</span>
              </a>

              <a
                href={CONTACT_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between rounded-xl border border-slate-300/15 bg-[#091221] p-4 transition-colors hover:border-slate-200/35 hover:bg-[#0E1B33] focus-visible:outline-2 focus-visible:outline-blue-400"
              >
                <div className="flex items-center gap-3.5">
                  <Instagram className="h-5 w-5 text-slate-300" aria-hidden="true" />
                  <div>
                    <p className="text-xs font-medium text-slate-400">Instagram Oficial</p>
                    <p className="text-sm font-semibold text-white">
                      @{CONTACT_INFO.instagramHandle}
                    </p>
                  </div>
                </div>
                <span className="text-xs font-semibold text-slate-300">Seguir perfil</span>
              </a>
            </div>
          </div>

          {/* Right Lead Capture Form */}
          <div className="lg:col-span-7">
            <form
              onSubmit={handleSubmit}
              noValidate
              className="rounded-2xl border border-slate-300/18 bg-[#091221] p-6 sm:p-8"
            >
              <h3 className="font-display text-xl font-semibold text-white">
                Solicitar orçamento personalizado
              </h3>
              <p className="mt-1 text-sm text-slate-400">
                Preencha os campos abaixo e envie diretamente para nosso WhatsApp.
              </p>

              <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2">
                <div>
                  <label
                    htmlFor="contact-name"
                    className="block text-xs font-semibold text-slate-200"
                  >
                    Seu nome completo
                  </label>
                  <input
                    id="contact-name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ex: Marcos Almeida"
                    aria-invalid={Boolean(errors.name)}
                    className="mt-2 min-h-[44px] w-full rounded-lg border border-slate-300/18 bg-[#05070B] px-3.5 text-sm text-white placeholder-slate-500 transition-colors focus:border-blue-500 focus:outline-none"
                  />
                  {errors.name && (
                    <p className="mt-1.5 text-xs font-medium text-red-400" role="alert">
                      {errors.name}
                    </p>
                  )}
                </div>

                <div>
                  <label
                    htmlFor="contact-phone"
                    className="block text-xs font-semibold text-slate-200"
                  >
                    Seu WhatsApp (com DDD)
                  </label>
                  <input
                    id="contact-phone"
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="(69) 9 9999-9999"
                    aria-invalid={Boolean(errors.phone)}
                    className="mt-2 min-h-[44px] w-full rounded-lg border border-slate-300/18 bg-[#05070B] px-3.5 text-sm text-white placeholder-slate-500 transition-colors focus:border-blue-500 focus:outline-none"
                  />
                  {errors.phone && (
                    <p className="mt-1.5 text-xs font-medium text-red-400" role="alert">
                      {errors.phone}
                    </p>
                  )}
                </div>

                <div>
                  <label
                    htmlFor="contact-segment"
                    className="block text-xs font-semibold text-slate-200"
                  >
                    Empresa ou segmento
                  </label>
                  <input
                    id="contact-segment"
                    type="text"
                    list="segment-suggestions"
                    value={segment}
                    onChange={(e) => setSegment(e.target.value)}
                    placeholder="Ex: Hamburgueria, Advocacia, Pilates..."
                    aria-invalid={Boolean(errors.segment)}
                    className="mt-2 min-h-[44px] w-full rounded-lg border border-slate-300/18 bg-[#05070B] px-3.5 text-sm text-white placeholder-slate-500 transition-colors focus:border-blue-500 focus:outline-none"
                  />
                  <datalist id="segment-suggestions">
                    {BUSINESS_SEGMENTS.map((seg) => (
                      <option key={seg.id} value={seg.name} />
                    ))}
                  </datalist>
                  {errors.segment && (
                    <p className="mt-1.5 text-xs font-medium text-red-400" role="alert">
                      {errors.segment}
                    </p>
                  )}
                </div>

                <div>
                  <label
                    htmlFor="contact-plan"
                    className="block text-xs font-semibold text-slate-200"
                  >
                    Plano de interesse
                  </label>
                  <select
                    id="contact-plan"
                    value={plan}
                    onChange={(e) => setPlan(e.target.value)}
                    className="mt-2 min-h-[44px] w-full rounded-lg border border-slate-300/18 bg-[#05070B] px-3.5 text-sm text-white transition-colors focus:border-blue-500 focus:outline-none"
                  >
                    {PRICING_PLANS.map((p) => (
                      <option key={p.id} value={p.name}>
                        {p.name} ({p.price})
                      </option>
                    ))}
                    <option value="Projeto sob medida">Outro / Projeto sob medida</option>
                  </select>
                </div>
              </div>

              <div className="mt-5">
                <label
                  htmlFor="contact-message"
                  className="block text-xs font-semibold text-slate-200"
                >
                  Conte rapidamente o que você precisa (opcional)
                </label>
                <textarea
                  id="contact-message"
                  rows={3}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Ex: Quero um site com cardápio digital e entrega rápida para começar a divulgar no Instagram."
                  className="mt-2 w-full rounded-lg border border-slate-300/18 bg-[#05070B] p-3.5 text-sm text-white placeholder-slate-500 transition-colors focus:border-blue-500 focus:outline-none"
                />
              </div>

              {submittedUrl && (
                <div
                  role="status"
                  className="mt-5 rounded-xl border border-emerald-400/30 bg-emerald-950/35 p-4"
                >
                  <div className="flex items-start gap-3">
                    <CheckCircle2
                      className="mt-0.5 h-5 w-5 shrink-0 text-emerald-400"
                      aria-hidden="true"
                    />
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-white">
                        Orçamento estruturado com sucesso!
                      </p>
                      <p className="mt-1 text-xs leading-relaxed text-slate-200">
                        Clique no botão abaixo para abrir seu atendimento imediato no WhatsApp com
                        todos os seus dados preenchidos.
                      </p>
                      <a
                        href={submittedUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="mt-3 inline-flex min-h-[42px] items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-emerald-500"
                      >
                        <MessageCircle className="h-4 w-4" aria-hidden="true" />
                        <span>Enviar mensagem agora no WhatsApp</span>
                      </a>
                    </div>
                  </div>
                </div>
              )}

              <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <button
                  type="submit"
                  className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-lg bg-[#1D4ED8] px-6 py-3 text-sm font-semibold text-white transition-colors duration-150 hover:bg-[#1E40AF] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-400"
                >
                  <MessageCircle className="h-4 w-4" aria-hidden="true" />
                  <span>Solicitar orçamento no WhatsApp</span>
                </button>

                <span className="text-xs text-slate-400">
                  Resposta rápida e atendimento humanizado.
                </span>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
