import { MessageCircle } from 'lucide-react';
import { getWhatsAppUrl } from '../data/agencyData';

export function FloatingWhatsApp() {
  return (
    <a
      href={getWhatsAppUrl()}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Solicitar orçamento no WhatsApp"
      className="fixed right-4 bottom-4 z-40 inline-flex h-13 w-13 items-center justify-center gap-2.5 rounded-full border border-slate-200/30 bg-[#1D4ED8] text-white shadow-[0_10px_30px_rgba(5,7,11,0.75)] transition-transform duration-150 hover:scale-[1.04] hover:bg-[#1E40AF] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-400 sm:right-6 sm:bottom-6 sm:h-12 sm:w-auto sm:rounded-full sm:px-5"
    >
      <MessageCircle className="h-5 w-5 shrink-0" aria-hidden="true" />
      <span className="hidden text-sm font-semibold whitespace-nowrap sm:inline">
        Orçamento no WhatsApp
      </span>
    </a>
  );
}
