export const CONTACT_INFO = {
  brandName: 'Premium Web',
  tagline: 'Sua empresa merece ser vista. Nós fazemos isso acontecer!',
  whatsappNumberRaw: '5569992578513',
  whatsappDisplay: '(69) 9 9257-8513',
  instagramHandle: 'premiumweb.oficial',
  instagramUrl: 'https://instagram.com/premiumweb.oficial',
  location: 'Atendimento em todo o Brasil',
} as const;

export function getWhatsAppUrl(message?: string): string {
  const defaultMsg =
    'Olá! Vim pelo portfólio da Premium Web e gostaria de solicitar um orçamento para o site da minha empresa.';
  const text = encodeURIComponent(message || defaultMsg);
  return `https://wa.me/${CONTACT_INFO.whatsappNumberRaw}?text=${text}`;
}

export const ABOUT_STORY = {
  heading: 'Por trás de cada site existe um sonho que merece se tornar realidade.',
  paragraph:
    'Sempre fui apaixonado por tecnologia e pela criação de sites. Há seis meses, transformei essa paixão em um propósito: ajudar pessoas e empresas a tirarem suas ideias do papel, conquistarem seu espaço na internet e alcançarem novos objetivos. Na Premium Web, cada projeto é desenvolvido com dedicação, atenção e compromisso, pois acreditamos que por trás de cada site existe um sonho que merece se tornar realidade.',
  pillars: [
    {
      index: '01',
      title: 'Atendimento Humanizado',
      description:
        'Você conversa direto com quem constrói seu projeto, sem robôs ou termos complicados. Entendemos o seu negócio para traduzir sua essência em vendas.',
    },
    {
      index: '02',
      title: 'Design Responsivo',
      description:
        'Mais de 80% dos seus clientes acessam pelo celular. Seu site nasce perfeito em smartphones, tablets e computadores, com carregamento imediato.',
    },
    {
      index: '03',
      title: 'Entrega Rápida no Mesmo Dia',
      description:
        'Seu faturamento não pode esperar semanas. Estruturamos, personalizamos e colocamos sua vitrine digital no ar com agilidade no mesmo dia.',
    },
  ],
};

export type SegmentCategory =
  | 'Todos'
  | 'Gastronomia'
  | 'Saúde & Beleza'
  | 'Automotivo & Serviços'
  | 'Comércio & Negócios';

export interface BusinessSegment {
  id: string;
  name: string;
  category: Exclude<SegmentCategory, 'Todos'>;
  focus: string;
}

export const SEGMENT_CATEGORIES: SegmentCategory[] = [
  'Todos',
  'Gastronomia',
  'Saúde & Beleza',
  'Automotivo & Serviços',
  'Comércio & Negócios',
];

export const BUSINESS_SEGMENTS: BusinessSegment[] = [
  // Gastronomia (6)
  {
    id: 'hamburgueria',
    name: 'Hamburgueria',
    category: 'Gastronomia',
    focus: 'Cardápio digital com pedido direto no WhatsApp',
  },
  {
    id: 'pizzaria',
    name: 'Pizzaria',
    category: 'Gastronomia',
    focus: 'Vitrine de sabores, combos e delivery ágil',
  },
  {
    id: 'acaiteria',
    name: 'Açaiteria',
    category: 'Gastronomia',
    focus: 'Montagem de copos e promoções locais',
  },
  {
    id: 'marmitaria',
    name: 'Marmitaria',
    category: 'Gastronomia',
    focus: 'Cardápio diário e pedidos recorrentes',
  },
  {
    id: 'padaria',
    name: 'Padaria',
    category: 'Gastronomia',
    focus: 'Encomendas, horários de fornada e localização',
  },
  {
    id: 'acougue',
    name: 'Casas de Açougues',
    category: 'Gastronomia',
    focus: 'Cortes selecionados e kits para churrasco',
  },

  // Saúde & Beleza (9)
  {
    id: 'design-sobrancelhas',
    name: 'Design de Sobrancelhas',
    category: 'Saúde & Beleza',
    focus: 'Portfólio de resultados e agendamento rápido',
  },
  {
    id: 'manicure',
    name: 'Manicure',
    category: 'Saúde & Beleza',
    focus: 'Catálogo de serviços e reserva de horário',
  },
  {
    id: 'academia',
    name: 'Academia',
    category: 'Saúde & Beleza',
    focus: 'Planos, modalidades e aula experimental',
  },
  {
    id: 'artes-marciais',
    name: 'Academias de Artes Marciais',
    category: 'Saúde & Beleza',
    focus: 'Grade de horários, instrutores e matrícula',
  },
  {
    id: 'nutricionista',
    name: 'Nutricionista',
    category: 'Saúde & Beleza',
    focus: 'Autoridade profissional e agendamento de consulta',
  },
  {
    id: 'personal-trainer',
    name: 'Personal Trainer',
    category: 'Saúde & Beleza',
    focus: 'Consultoria presencial ou online com conversão direta',
  },
  {
    id: 'fisioterapeuta',
    name: 'Fisioterapeuta',
    category: 'Saúde & Beleza',
    focus: 'Especialidades clínicas e marcação de avaliação',
  },
  {
    id: 'studio-pilates',
    name: 'Studio de Pilates',
    category: 'Saúde & Beleza',
    focus: 'Estrutura do espaço e agendamento de sessão',
  },
  {
    id: 'farmacias',
    name: 'Farmácias',
    category: 'Saúde & Beleza',
    focus: 'Atendimento farmacêutico rápido e televendas',
  },

  // Automotivo & Serviços (7)
  {
    id: 'mecanica-automotiva',
    name: 'Mecânica Automotiva',
    category: 'Automotivo & Serviços',
    focus: 'Agendamento de revisão e orçamento transparente',
  },
  {
    id: 'lava-rapido',
    name: 'Lava-Rápido',
    category: 'Automotivo & Serviços',
    focus: 'Pacotes de higienização e estética automotiva',
  },
  {
    id: 'assistencia-tecnica',
    name: 'Assistência Técnica',
    category: 'Automotivo & Serviços',
    focus: 'Orçamento de reparo em celulares e eletrônicos',
  },
  {
    id: 'vidracaria',
    name: 'Vidraçaria',
    category: 'Automotivo & Serviços',
    focus: 'Galeria de projetos e solicitação de medidas',
  },
  {
    id: 'fotografo',
    name: 'Fotógrafo',
    category: 'Automotivo & Serviços',
    focus: 'Portfólio visual imersivo e reserva de datas',
  },
  {
    id: 'despachantes',
    name: 'Despachantes',
    category: 'Automotivo & Serviços',
    focus: 'Documentação veicular ágil e atendimento direto',
  },
  {
    id: 'pet-shop',
    name: 'Pet Shop',
    category: 'Automotivo & Serviços',
    focus: 'Banho, tosa e produtos com agendamento fácil',
  },

  // Comércio & Negócios (9)
  {
    id: 'advocacia',
    name: 'Escritório de Advocacia',
    category: 'Comércio & Negócios',
    focus: 'Posicionamento sóbrio e captação ética de clientes',
  },
  {
    id: 'contabilidade',
    name: 'Escritório de Contabilidade',
    category: 'Comércio & Negócios',
    focus: 'Soluções para empresas e abertura de CNPJ',
  },
  {
    id: 'imobiliaria',
    name: 'Imobiliária',
    category: 'Comércio & Negócios',
    focus: 'Destaque de imóveis e contato imediato com corretor',
  },
  {
    id: 'escola-idiomas',
    name: 'Escola de Idiomas',
    category: 'Comércio & Negócios',
    focus: 'Captação de novos alunos e teste de nível',
  },
  {
    id: 'mercados',
    name: 'Mercados',
    category: 'Comércio & Negócios',
    focus: 'Ofertas da semana, localização e entregas',
  },
  {
    id: 'papelaria-artesanatos',
    name: 'Papelaria e Artesanatos',
    category: 'Comércio & Negócios',
    focus: 'Vitrine de peças personalizadas e encomendas',
  },
  {
    id: 'oticas',
    name: 'Óticas',
    category: 'Comércio & Negócios',
    focus: 'Armações, lentes e agendamento de atendimento',
  },
  {
    id: 'floriculturas',
    name: 'Floriculturas',
    category: 'Comércio & Negócios',
    focus: 'Buquês e presentes com entrega rápida no dia',
  },
  {
    id: 'produtos-naturais',
    name: 'Produtos Naturais',
    category: 'Comércio & Negócios',
    focus: 'Catálogo saudável e pedidos pelo WhatsApp',
  },
];

export interface PortfolioProject {
  id: string;
  title: string;
  client: string;
  segment: string;
  location: string;
  resultMetric: string;
  image: string;
  imageAlt: string;
  summary: string;
  challenge: string;
  solution: string;
  deliverables: string[];
  featured?: boolean;
}

export const PORTFOLIO_PROJECTS: PortfolioProject[] = [
  {
    id: 'brasa-artesanal',
    title: 'Cardápio Digital & Pedido Direto',
    client: 'Brasa & Grão Burger',
    segment: 'Hamburgueria Artesanal',
    location: 'Porto Velho, RO',
    resultMetric: '+64% em pedidos diretos via WhatsApp em 45 dias',
    image: '/src/assets/images/portfolio_gastronomia_1794594313272.jpg',
    imageAlt: 'Site escuro e sofisticado desenvolvido para hamburgueria artesanal exibido em notebook',
    summary:
      'Página de alta conversão focada em fotografia apetitosa, carregamento instantâneo no 4G e botão de pedido direto sem taxas de aplicativos.',
    challenge:
      'A hamburgueria dependia exclusivamente de aplicativos de delivery com taxas altas e perdia clientes do Instagram por falta de um cardápio claro.',
    solution:
      'Criamos uma vitrine em tema escuro premium que valoriza os lanches artesanais e leva o cliente do cardápio ao fechamento no WhatsApp em dois cliques.',
    deliverables: ['Design Responsivo Mobile-First', 'Cardápio Interativo', 'Botão Direto WhatsApp', 'SEO Local Google'],
    featured: true,
  },
  {
    id: 'mendes-silveira-advocacia',
    title: 'Presença Institucional de Autoridade',
    client: 'Mendes & Silveira Advogados',
    segment: 'Escritório de Advocacia',
    location: 'São Paulo, SP',
    resultMetric: '3,2x mais agendamentos qualificados no primeiro mês',
    image: '/src/assets/images/portfolio_advocacia_1794594314490.jpg',
    imageAlt: 'Monitor em mesa escura exibindo site institucional de advocacia em azul marinho e branco',
    summary:
      'Arquitetura sóbria em azul marinho e detalhes metálicos que transmite confiança imediata para clientes corporativos e pessoas físicas.',
    challenge:
      'O escritório não possuía presença web própria e perdia credibilidade frente a concorrentes ao enviar apenas perfis de redes sociais.',
    solution:
      'Desenvolvemos um portal institucional enxuto, apresentando áreas de atuação, corpo jurídico e triagem inicial integrada ao WhatsApp do escritório.',
    deliverables: ['Identidade Visual Digital', 'Áreas de Atuação', 'Triagem WhatsApp', 'Entrega no Mesmo Dia'],
  },
  {
    id: 'core-pilates-studio',
    title: 'Agenda & Vitrine de Bem-Estar',
    client: 'Core Studio Pilates',
    segment: 'Studio de Pilates',
    location: 'Curitiba, PR',
    resultMetric: '92% de ocupação das turmas matinais em 60 dias',
    image: '/src/assets/images/portfolio_saude_pilates_1794594314252.jpg',
    imageAlt: 'Site responsivo de Studio de Pilates exibido lado a lado em tablet e smartphone',
    summary:
      'Experiência mobile impecável para interessadas conhecerem a estrutura do estúdio e marcarem uma aula experimental em segundos.',
    challenge:
      'As interessadas precisavam esperar horas por respostas no direct para descobrir horários disponíveis e planos.',
    solution:
      'Estruturamos modalidades, diferenciais do método e agendamento guiado por mensagem pronta no WhatsApp.',
    deliverables: ['Layout Tablet & Mobile', 'Grade de Modalidades', 'Agendamento em 1 Clique', 'Velocidade Otimizada'],
  },
  {
    id: 'premium-web-architecture',
    title: 'Portal Corporativo & Conversão B2B',
    client: 'Vanguard Engenharia & Vidros',
    segment: 'Vidraçaria & Esquadrias',
    location: 'Belo Horizonte, MG',
    resultMetric: '+110% em solicitações de orçamento para obras',
    image: '/src/assets/images/hero_premium_studio_1794594313004.jpg',
    imageAlt: 'Display widescreen exibindo site corporativo escuro e minimalista com fotografia arquitetônica',
    summary:
      'Vitrine arquitetônica desenvolvida para construtoras e clientes residenciais solicitarem visita técnica com rapidez.',
    challenge:
      'Projetos de alto padrão não eram valorizados em fotos soltas no celular e os orçamentos chegavam sem informações mínimas.',
    solution:
      'Criamos uma galeria técnica por tipo de ambiente aliada a um formulário inteligente que já envia as medidas preliminares ao WhatsApp.',
    deliverables: ['Galeria de Obras', 'Formulário Pré-Orçamento', 'Visual Alto Contraste', 'Suporte Humanizado'],
  },
];

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  city: string;
  outcome: string;
  quote: string;
}

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 't1',
    name: 'Rafael Oliveira',
    role: 'Proprietário',
    company: 'Brasa & Grão Burger',
    city: 'Porto Velho, RO',
    outcome: '+64% pedidos diretos sem comissão',
    quote:
      'Antes eu dependia só dos aplicativos e deixava quase um terço do lucro em taxas. Em menos de 24 horas a Premium Web colocou nosso site no ar com um atendimento super atencioso. Hoje nossos clientes pedem direto pelo WhatsApp.',
  },
  {
    id: 't2',
    name: 'Dra. Camila Silveira',
    role: 'Sócia-Fundadora',
    company: 'Mendes & Silveira Advogados',
    city: 'São Paulo, SP',
    outcome: '3,2x mais contatos qualificados',
    quote:
      'Precisávamos de um site sério, elegante e que passasse autoridade logo no primeiro olhar. O cuidado com os detalhes em azul marinho e a agilidade na entrega no mesmo dia superaram qualquer agência com quem já conversamos.',
  },
  {
    id: 't3',
    name: 'Juliana Ferreira',
    role: 'Diretora Técnica',
    company: 'Core Studio Pilates',
    city: 'Curitiba, PR',
    outcome: 'Agenda matinal preenchida em 60 dias',
    quote:
      'Eu não entendia nada de tecnologia e tinha receio de ser complicado. O atendimento humanizado fez toda a diferença: fui ouvida em cada etapa e o site ficou impecável no celular das minhas alunas.',
  },
];

export interface PricingPlan {
  id: string;
  name: string;
  subtitle: string;
  price: string;
  billingNote: string;
  delivery: string;
  image: string;
  imageAlt: string;
  recommended?: boolean;
  features: string[];
  ctaLabel: string;
}

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: 'simples',
    name: 'Site Simples',
    subtitle: 'Ideal para quem está começando!',
    price: 'R$ 200,00',
    billingNote: 'Pagamento único',
    delivery: 'Entrega rápida',
    image: '/assets/aistudio/WhatsApp_Image_2026-11-13_at_15.30.00_16d79a20.jpeg',
    imageAlt: 'Arte promocional do plano Site Simples da Premium Web por R$ 200,00',
    features: [
      'Página única e moderna',
      'Design responsivo (se adapta a qualquer dispositivo)',
      'Contato direto (via WhatsApp)',
      'Entrega rápida',
    ],
    ctaLabel: 'Solicitar Site Simples',
  },
  {
    id: 'essencial',
    name: 'Site Essencial',
    subtitle: 'O equilíbrio perfeito entre preço e recursos!',
    price: 'R$ 300,00',
    billingNote: 'Pagamento único',
    delivery: 'Entrega rápida · Otimizado para Google',
    image: '/assets/aistudio/WhatsApp_Image_2026-11-13_at_16.03.54_d4aeff79.jpeg',
    imageAlt: 'Arte promocional do plano Site Essencial da Premium Web por R$ 300,00',
    recommended: true,
    features: [
      'Páginas completas (institucional, serviços, contato)',
      'Design profissional',
      'Otimizado para Google',
      'Integração com WhatsApp',
      'Suporte especializado',
    ],
    ctaLabel: 'Solicitar Site Essencial',
  },
  {
    id: 'premium',
    name: 'Site Premium',
    subtitle: 'Para quem quer destaque total!',
    price: 'R$ 400,00',
    billingNote: 'Pagamento único',
    delivery: 'Suporte prioritário · SEO avançado',
    image: '/assets/aistudio/WhatsApp_Image_2026-11-13_at_16.03.53_6cd5c6d8.jpeg',
    imageAlt: 'Arte promocional do plano Site Premium da Premium Web por R$ 400,00',
    features: [
      'Site completo e avançado',
      'Design exclusivo',
      'Otimização SEO avançada',
      'Integrações personalizadas (redes sociais, sistemas)',
      'Suporte prioritário',
    ],
    ctaLabel: 'Solicitar Site Premium',
  },
];
